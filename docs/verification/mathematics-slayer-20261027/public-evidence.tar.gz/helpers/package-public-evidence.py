#!/usr/bin/env python3
"""Deterministic, lossless public evidence from a hash-pinned explicit allowlist.
Never discovers inputs recursively; never copies a private output directory.
"""
import argparse,gzip,hashlib,json,os,tarfile
from pathlib import Path,PurePosixPath
BLOCKED_PARTS={'tmp','private','private-inputs','downloads','profiles','browser-profiles','node_modules','.git','recovered-blobs','payloads','preupload-payloads','__pycache__'}
BLOCKED_NAMES={'mathematics-slayer-save.json','mathematics-slayer-learning-backup.json','slay-the-math-save.json','slay-the-math-learning-backup.json'}

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def safe_rel(value):
 if not isinstance(value,str) or not value or '\\' in value:raise ValueError('POSIX relative path required')
 p=PurePosixPath(value)
 if p.is_absolute() or '..' in p.parts or str(p)!=value:raise ValueError('Unsafe/noncanonical path '+value)
 for part in p.parts:
  low=part.lower()
  if low in BLOCKED_PARTS or low.startswith(('stm-pending-private-inputs','stm-private','private-','qa-private','master-rename-qa-tmp')):raise ValueError('Private/temporary/dependency path excluded: '+value)
 if p.name.lower() in BLOCKED_NAMES:raise ValueError('Raw export payload excluded: '+value)
 return p

def package(root,manifest_file,out):
 root=root.resolve();a=json.loads(manifest_file.read_text())
 if a.get('publicApproved') is not True or a.get('privacyReview',{}).get('status')!='PASS':raise ValueError('Explicit public approval and completed privacy PASS required')
 if not a.get('files'):raise ValueError('No approved inputs')
 entries=[];seen=set()
 for row in sorted(a['files'],key=lambda x:x['path']):
  rel=safe_rel(row['path']);name=str(rel)
  if name in seen:raise ValueError('Duplicate input '+name)
  seen.add(name);p=root/name
  if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(root):raise ValueError('Regular source-root file required '+name)
  # Reject symlink directory traversal too, even if it resolves back inside root.
  if any(x.is_symlink() for x in p.parents if x!=root and x.is_relative_to(root)):raise ValueError('Symlink parent '+name)
  size=p.stat().st_size;digest=sha(p)
  if size!=row['bytes'] or digest!=row['sha256']:raise ValueError('Input identity changed '+name)
  entries.append({'originalPath':name,'archivePath':name,'bytes':size,'sha256':digest,'mode':p.stat().st_mode&0o777})
 out.mkdir(parents=True,exist_ok=True);archive=out/'public-evidence.tar.gz';partial=out/'public-evidence.tar.gz.partial'
 with partial.open('wb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=6) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as t:
    for row in entries:
     i=tarfile.TarInfo(row['archivePath']);i.size=row['bytes'];i.mode=row['mode'];i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
     with (root/row['originalPath']).open('rb') as f:t.addfile(i,f)
 result=verify(partial,entries)
 # Ensure producer did not change a file during archive creation.
 for row in entries:
  p=root/row['originalPath']
  if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise ValueError('Source changed while packing '+row['originalPath'])
 os.replace(partial,archive)
 index={'format':'deterministic-tar-gzip','archive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'sourceManifestSha256':sha(manifest_file),'originalFiles':len(entries),'originalBytes':sum(x['bytes'] for x in entries),'roundtrip':result,'privacy':a['privacyReview'],'excludedByPolicy':['private inputs/raw saves/downloads','temporary profiles/dependencies','recovered source copies','upload payloads'],'entries':entries}
 (out/'evidence-index.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n');return index

def verify(archive,entries):
 with tarfile.open(archive,'r:gz') as t:
  members=t.getmembers()
  if len(members)!=len(entries) or len({m.name for m in members})!=len(entries):raise ValueError('Member count/duplicate mismatch')
  for m,row in zip(members,entries):
   safe_rel(m.name)
   if not m.isfile() or m.name!=row['archivePath'] or m.size!=row['bytes'] or m.mode!=row['mode']:raise ValueError('Mapping/length/mode mismatch '+m.name)
   h=hashlib.sha256()
   with t.extractfile(m) as f:
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
   if h.hexdigest()!=row['sha256']:raise ValueError('Archive bytes mismatch '+m.name)
 return {'status':'PASS','verifiedOriginals':len(entries),'mismatches':0,'duplicatePaths':0,'extractedToDisk':False}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();r=package(a.source_root,a.manifest,a.output_dir);print(json.dumps({k:v for k,v in r.items() if k!='entries'},indent=2))
