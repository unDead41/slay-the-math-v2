# Recovery audit — inventory and affected owners

Checked 27 October 2026. Repository `unDead41/slay-the-math-v2`; actual GitHub main `ce586507dd5a5b55a72ee008ec60a547cd5c2b7e`, tree `5bb15d461d72b8d200ebd0f64071525e6938f58d`, game2.51.0. Master SOR1.2.0 read first, then current AGENTS/governance and relevant owner/release/audit sources. Explicit current user authorization approves active Mathematics Slayer identity and main publication; repository/URLs/IDs/saves remain outside a technical migration.

**VALID for fresh inventory only. New candidate compatibility remains BELUM DISAHKAN pending an exact source checkpoint and fresh capture/QA evidence.** No repository edits, build, tests, browser, simulation or training were performed by this auditor. Deleted prior 2.52 captures/proofs are not used as current evidence. Main was rechecked unchanged at inventory closure.

| Classification | Count | Meaning |
| --- | ---: | --- |
| Exact heads are main ancestors | 19 | Already in ancestry; later owner changes remain authoritative. |
| Historical entire-tree adoption | 14 | All exact source trees equal historical adoption trees that remain main ancestors. |
| Historical selective specialist adoption | 3 | Combat/Economy/Map findings or adapters are adopted; raw history and old source assertions are not wholesale merged. |
| Superseded catalogue-only BM preview | 1 | Whole-game language2.43 and current card owner supersede it. |

No newly actionable gameplay package was found. Current-main Master refresh explicitly records the three specialist dispositions. Eighteen old-BM changed blobs are present in current card supplier paths, including documentation/tests/provenance; this is not eighteen independent features. Map has six exact functional files and six adapted current owner files. Current agent cap is three.

Initial current-source residual review found no additional missed active player/Dev product label beyond the root's renamed owners. Remaining old names are stable storage/protocol/global/URL identities, legacy portable alias, frozen supplier identities, source/license/import provenance and historical package tools. The original procedural-score generator is outside the current normal/prod scripts; preserve original audio bytes. Full visual scope waits for new captures; voice transcripts are not inferred from filenames or metadata.

Next static audit binds new SHA/tree to baseline owner blobs, active UI/export/generated/docs naming, current raw-app Tutorial provenance and fresh 98 capture hashes, normal/prod/offline manifests and exact portable alias parity. Preserve known CI-247-01 and QA-248-PRELOAD-01 P2/open. MODEL.zip is unavailable/unread. Three PDFs are available but unread because mathematics content remains unchanged.

Evidence: `inventory-37-current-main.json` (`a3b1ca1e90f98940d010d86b43a2ec9397912f8d5c7073aaeff9b70f062fdff1`), `historical-residual-dispositions.json` (`0c4b142852283a2f137b3c5b604cc9d8b4b5a988c974bdbf81703645d541f463`), `affected-owner-static-plan.json` (`d06b4df56e0e950f8a7e84cef53daf4445f9c293028fb804eb61b7b1c0d99f5b`). All are recovery-session artifacts outside Git.
