# QA — Mathematics Slayer 2.52.0

**CLOSED / VALID dalam skop yang diuji, dengan P2 dan had bukti dikekalkan.**

Calon `d8e92d82e472dbdf1dde294e944049e902394140`, tree `eea5bdefd0b4128ceff34273c037fc10c9aa29cb`, ditutup pada `2026-10-27T04:53:20.552751+00:00`. Snapshot remote `39f8d1302173c1dd817442a865b2b0bbd504dd92` mempunyai tree tepat sama mengikut bukti coordinator.

| Semakan | Keputusan |
| --- | --- |
| Ujian tertumpu 22 fail | Log asal: 170 nama PASS, exit 0, tiada jumlah akhir. Empat fail hujung: **30/30 PASS**, 0 fail/skip/cancel. **200 kes unik** tanpa pertindihan; bukan satu command 200/200. |
| Native offline dan nama | **14/14 PASS**: restart proses browser, server dihentikan, network disekat, HTTP cache dimatikan, navigasi melalui SW; versi 2.52.0 dan nama baharu. |
| Kedua-dua portable | **2/2 PASS**, canonical EN dan alias lama BM; 0 HTTP/page errors, save/RNG lama tepat, eksport sebenar dan 120 soalan Practice. |
| Developer Hub | **PASS** melalui Settings produksi sebenar, unlock dan reload; tajuk serta heading baharu. |
| Fit menu EN/BM | **8/8 PASS**, 320/390/844 landscape/1440. Tujuh butang sekurang-kurangnya 44px, dalam batas mendatar dan boleh dicapai dengan scroll biasa. |
| Capture pemilik | **98 gambar sebenar**, 49 EN/49 BM, 422.855s; 107 input runtime tanpa drift. Log asal separa dikekalkan; metadata, katalog dan hash 98 gambar lengkap. |
| Identiti penutupan | **3,659 fail tracked tanpa delta**, kedua-dua portable sama tepat; **766 entry produksi** sepadan hash dan saiz. |

Dua FAIL preflight dikekalkan: casing fixture luaran `Learn` dan konfigurasi font tool yang menghasilkan teks kosong. Pembetulan hanya pada fixture dan toolenv; tiada perubahan produk atau pengurangan assertion. Kegagalan muat turun CDN turut disimpan. Kemajuan log yang kelihatan terhenti tidak membuktikan hang/crash; tiada capture ulangan atau interruption sebenar.

Native meliputi 23 bab, 114 pendedahan gambar/98 unik EN/BM, 85 MP3 decode, satu sumber Web Audio muted, empat fixture stage/boss, aktor/VFX sebenar dan kesamaan battle/RNG/deck/stats. Ini bukan kempen penuh atau human audition.

**Privacy PASS:** hanya nama fail, saiz, hash, schema, label dan hasil perbandingan eksport diterbitkan. Body save/session/RNG/backup, profil browser, temp dan dependencies dikecualikan; tiada body download tinggal. Tiada rekod pemain sebenar digunakan.

CI-247-01 dan QA-248-PRELOAD-01 kekal P2/open. D1/D2 sejarah tidak ditutup. Full suite, 75-pose matrix, kempen/training, live Google/provider, public Pages browser, peranti fizikal/OS reboot/hardware GPU/browser lain, human audio dan MODEL.zip **NOT_RUN**. Setiap alias diuji dengan fixture tersendiri; tiada jaminan migrasi storage automatik antara file origins.

Bukti: [evidence.json](evidence.json), [focused coverage](focused-coverage.json), [closing snapshot](final-source-after.json), [privacy](privacy.json), [allowlist](artifact-index.json). Artifak QA 4b lama telah hilang dan tidak digunakan sebagai bukti baharu. QA tidak menulis main/ref.
