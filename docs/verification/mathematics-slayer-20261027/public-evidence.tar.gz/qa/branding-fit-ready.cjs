/* Disposable actual-player preflight. No build or product edits. */
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn,execFileSync}=require('node:child_process');
const {chromium}=require(process.env.BROWSER_QA_MODULE);
const root='/workspace/scratch/e7745ff161c8/stm-recovery-20261027',out=__dirname;
const E=require(path.join(root,'dist/engine.js')),{legacyRun}=require(path.join(root,'tests/helpers/legacy-run.cjs'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),read=f=>fs.readFileSync(path.join(root,f));
const report={startedUTC:new Date().toISOString(),candidateSHA:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),candidateTree:execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:root,encoding:'utf8'}).trim(),sourceWorkingTreeDirty:!!execFileSync('git',['status','--short','--untracked-files=no'],{cwd:root,encoding:'utf8'}).trim(),appSHA256:hash(read('dist/app.js')),manifestSHA256:hash(read('dist/asset-manifest.json')),checks:[],errors:[],externalRequests:[]};
let server,browser,context;
const serverLog=fs.openSync(path.join(out,'branding-fit-ready-server.log'),'w');
(async()=>{
 try{
  server=spawn(process.execPath,['server.cjs'],{cwd:root,env:{...process.env,PORT:'4198'},stdio:['ignore','pipe','pipe']});
  server.stdout.on('data',b=>fs.writeSync(serverLog,b));server.stderr.on('data',b=>fs.writeSync(serverLog,b));
  await new Promise((ok,no)=>{server.once('error',no);server.stdout.once('data',ok);server.stderr.once('data',b=>no(Error(String(b))));});
  const options={headless:true,executablePath:process.env.QA_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--disable-gpu']};
  if(process.env.QA_CHROMIUM_MODULE){const imported=require(process.env.QA_CHROMIUM_MODULE),c=imported.default||imported;options.args=[...c.args.filter(x=>!['--single-process','--disable-web-security'].includes(x)),...options.args];}
  browser=await chromium.launch(options);report.browserVersion=browser.version();
  const fixture=legacyRun(7351,'learn');assert.ok(E.validate(fixture));assert.equal(fixture.deck.length,12);
  report.legacyFixture={key:'duel-cube-math.v1',seed:7351,deckCount:12,sha256:hash(JSON.stringify(fixture))};
  for(const language of ['en','ms'])for(const [width,height] of [[320,568],[390,844],[844,390],[1440,900]]){
   context=await browser.newContext({viewport:{width,height},serviceWorkers:'block',reducedMotion:'reduce'});
   await context.route('**/*',route=>{const u=route.request().url();if(/^https?:\/\/(127\.0\.0\.1|localhost):4198\//.test(u))return route.continue();report.externalRequests.push(u);return route.abort();});
   await context.addInitScript(({language,fixture})=>{localStorage.setItem('slay-the-math.question-language.v1',language);localStorage.setItem('duel-cube-settings.v1',JSON.stringify({motion:false,sound:false,musicMuted:true,voiceMuted:true}));localStorage.setItem('duel-cube-math.v1',JSON.stringify(fixture));},{language,fixture});
   const page=await context.newPage();page.setDefaultTimeout(30000);page.on('pageerror',e=>report.errors.push(e.message));await page.goto('http://127.0.0.1:4198/');
   await page.locator('#resource-enter').waitFor({state:'visible',timeout:120000});assert.match(await page.title(),/Mathematics Slayer/);assert.equal(await page.locator('#resource-loader small').isVisible(),true);assert.equal((await page.locator('#resource-loader small').innerText()).trim(),'MATHEMATICS SLAYER');
   await page.locator('#resource-enter').click();await page.locator('.main-menu-actions').waitFor();await page.evaluate(()=>document.fonts.ready);
   assert.equal(await page.title(),'Mathematics Slayer');assert.equal((await page.locator('.home-title h1').innerText()).replace(/\s+/g,' ').trim(),'Mathematics Slayer');assert.equal(await page.locator('.main-menu-actions button').count(),7);assert.equal(await page.locator('.main-menu-actions [data-action=continue]').isEnabled(),true);
   const geometry=await page.evaluate(()=>{const h=document.querySelector('.home-title h1'),r=h.getBoundingClientRect(),range=document.createRange();range.selectNodeContents(h);const text=range.getBoundingClientRect();return {viewport:{width:innerWidth,height:innerHeight},documentWidth:document.documentElement.scrollWidth,title:{x:r.x,y:r.y,width:r.width,height:r.height,textX:text.x,textWidth:text.width},buttons:[...document.querySelectorAll('.main-menu-actions button')].map(b=>{const r=b.getBoundingClientRect();return {action:b.dataset.action,x:r.x,width:r.width,height:r.height};})};});
   assert.ok(geometry.documentWidth<=width+1);assert.ok(geometry.title.textX>=-1&&geometry.title.textX+geometry.title.textWidth<=width+1);assert.ok(geometry.title.textWidth<=geometry.title.width+1);
   for(const button of geometry.buttons){assert.ok(button.x>=-1&&button.x+button.width<=width+1,button.action+' horizontal bounds');assert.ok(button.height>=44,button.action+' touch height');}
   // The menu may scroll vertically on short screens. Check genuine reachability,
   // without claiming all seven controls are visible at the same time.
   for(const button of await page.locator('.main-menu-actions button').all())await button.scrollIntoViewIfNeeded();
   const saved=await page.evaluate(()=>JSON.parse(localStorage.getItem('duel-cube-math.v1')));
   for(const key of ['seed','scene','rng','deck','hp','gold'])assert.deepEqual(saved[key],fixture[key],key+' legacy readback');
   await page.evaluate(()=>window.scrollTo(0,0));const screenshot=`fit-${language}-${width}x${height}.png`;await page.screenshot({path:path.join(out,screenshot)});
   report.checks.push({language,viewport:{width,height},title:'Mathematics Slayer',geometry,menuControls:7,buttonsReachableWithOrdinaryScroll:true,legacySaveAndRNGUnchanged:true,screenshot});console.log('PASS fit '+language+' '+width+'x'+height);
   await context.close();context=null;
  }
  assert.deepEqual(report.errors,[]);assert.deepEqual(report.externalRequests,[]);assert.equal(report.checks.length,8);assert.equal(hash(read('dist/app.js')),report.appSHA256);console.log('PASS 8/8 actual menu fit + legacy save preflights');
 }catch(error){report.failure=error.stack||String(error);throw error;}
 finally{await context?.close();await browser?.close();if(server){server.kill();await new Promise(r=>server.once('exit',r));}fs.closeSync(serverLog);report.closedUTC=new Date().toISOString();fs.writeFileSync(path.join(out,'branding-fit-ready-report.json'),JSON.stringify(report,null,2)+'\n');}
})().catch(error=>{console.error(error);process.exitCode=1;});
