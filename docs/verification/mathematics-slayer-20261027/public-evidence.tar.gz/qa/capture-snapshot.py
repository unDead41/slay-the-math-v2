#!/usr/bin/env python3
"""Hash owner capture inputs/media before and after the unchanged capture CLI."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

QA = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e7745ff161c8/stm-recovery-20261027')
mode = sys.argv[1]
if mode not in ['before', 'after']:
    raise SystemExit('before or after')
sha = lambda b: hashlib.sha256(b).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines()
dist = REPO / 'dist'
runtime = {p.name: sha(p.read_bytes()) for p in sorted(dist.iterdir()) if p.suffix in ['.html', '.js', '.css']}
catalogue_path = REPO / 'docs/tutorial/screenshots.json'
catalogue_bytes = catalogue_path.read_bytes()
catalogue = json.loads(catalogue_bytes)
bitmaps = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted((dist / 'assets').glob('tutorial-shot-*.webp'))}
record = {'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidateSHA': head[0], 'candidateTree': head[1], 'runtimeInputs': runtime, 'runtimeInputCount': len(runtime), 'catalogueSHA256': sha(catalogue_bytes), 'catalogueSourceCommit': catalogue.get('sourceCommit'), 'catalogue': catalogue, 'bitmaps': bitmaps}
if mode == 'after':
    before = json.loads((QA / 'tutorial-capture-before.json').read_text())
    record['runtimeDelta'] = [k for k in sorted(set(runtime) | set(before['runtimeInputs'])) if runtime.get(k) != before['runtimeInputs'].get(k)]
    record['bitmapDelta'] = [k for k in sorted(set(bitmaps) | set(before['bitmaps'])) if bitmaps.get(k) != before['bitmaps'].get(k)]
    record['uniquePairs'] = len({(i['id'], i['language']) for i in catalogue['images']})
    record['languageCounts'] = {lang: sum(i['language'] == lang for i in catalogue['images']) for lang in ['en', 'ms']}
    record['actualBitmapMismatches'] = [i['file'] for i in catalogue['images'] if bitmaps.get(i['file']) != {'bytes': i['bytes'], 'sha256': i['sha256']}]
    record['captureRuntimeMatches'] = all(catalogue['runtimeSnapshots'][i['inputDigest']] == runtime for i in catalogue['images'])
    record['sourceCommitMatches'] = catalogue.get('sourceCommit') == head[0]
    record['sourceWorkingTreeDirty'] = catalogue.get('sourceWorkingTreeDirty')
    record['actualTotalImageBytes'] = sum(i['bytes'] for i in catalogue['images'])
    assert not record['runtimeDelta'], 'Runtime changed during capture'
    assert not record['actualBitmapMismatches'], 'Capture bytes disagree with catalogue'
    assert record['uniquePairs'] == 98 and record['languageCounts'] == {'en': 49, 'ms': 49}
    assert record['captureRuntimeMatches'] and record['sourceCommitMatches']
    assert record['sourceWorkingTreeDirty'] is False
filename = 'tutorial-capture-before.json' if mode == 'before' else 'tutorial-capture-integrity.json'
(QA / filename).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k not in ['runtimeInputs', 'catalogue', 'bitmaps', 'bitmapDelta']}, indent=2))
