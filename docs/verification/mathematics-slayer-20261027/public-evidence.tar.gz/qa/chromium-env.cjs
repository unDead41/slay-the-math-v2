/* Environment adapter only: verified task-owned extraction, actual package args. */
'use strict';
const fs=require('node:fs');
const imported=require('/workspace/scratch/e7745ff161c8/rename-recovery-deps/node_modules/@sparticuz/chromium/build/index.js');
const chromium=imported.default||imported;
const executable='/workspace/scratch/e7745ff161c8/rename-recovery-tmp/chromium';
module.exports={args:chromium.args,async executablePath(){if(fs.statSync(executable).size!==209022176)throw Error('Verified Chromium extraction changed');return executable;}};
