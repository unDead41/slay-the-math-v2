#!/usr/bin/env python3
"""Record task-owned QA commands without printing or copying private save bodies."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

QA = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e7745ff161c8/stm-recovery-20261027')
TASK = QA.parents[1]
name, *command = sys.argv[1:]
if not command:
    raise SystemExit('usage: run-command.py NAME COMMAND [ARG ...]')
env = dict(os.environ)
env.update({
    'DOM_QA_MODULE': str(TASK / 'rename-recovery-deps/node_modules/jsdom'),
    'BROWSER_QA_MODULE': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright',
    'SHARP_QA_MODULE': '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp',
    'QA_PROFILE_ROOT': str(TASK / 'rename-recovery-tmp'),
    'TMPDIR': str(TASK / 'rename-recovery-tmp'),
    'NODE_OPTIONS': '--max-old-space-size=1792',
})
environment_file = QA / 'environment.json'
if environment_file.exists():
    environment = json.loads(environment_file.read_text())
    env['QA_CHROMIUM_EXECUTABLE'] = environment['chromium']['executable']
    env.update(environment['chromium'].get('environment', {}))
    # Owner capture supports the published package arguments. Canonical native
    # scripts continue using their own unchanged launch options.
    env['QA_CHROMIUM_MODULE'] = environment['chromium']['module']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines()
tick = time.monotonic()
with (QA / (name + '.log')).open('w') as log:
    completed = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
record = {
    'command': command, 'cwd': str(REPO), 'startedUTC': started,
    'seconds': round(time.monotonic() - tick, 3), 'exitCode': completed.returncode,
    'candidateSHA': before[0], 'candidateTree': before[1],
    'environment': {k: env[k] for k in ['DOM_QA_MODULE', 'BROWSER_QA_MODULE', 'SHARP_QA_MODULE', 'QA_PROFILE_ROOT', 'TMPDIR', 'NODE_OPTIONS', 'QA_CHROMIUM_EXECUTABLE', 'QA_CHROMIUM_MODULE', 'FONTCONFIG_PATH', 'QA_OUTPUT'] if k in env},
    'log': name + '.log',
}
(QA / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(completed.returncode)
