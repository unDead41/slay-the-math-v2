#!/usr/bin/env python3
"""Source and generated-artifact identity, without copying file contents."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

QA = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e7745ff161c8/stm-recovery-20261027')
name = sys.argv[1]
def digest(file):
    h = hashlib.sha256()
    with file.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return {'bytes': file.stat().st_size, 'sha256': h.hexdigest()}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines()
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
tracked = {n: digest(REPO / n) for n in names if n}
artifacts = {n: digest(REPO / n) for n in ['MATHEMATICS-SLAYER-OFFLINE.html', 'SLAY-THE-MATH-OFFLINE.html', 'release-prod/index.html', 'release-prod/asset-manifest.json'] if (REPO / n).is_file()}
record = {'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidateSHA': head[0], 'candidateTree': head[1], 'trackedCount': len(tracked), 'tracked': tracked, 'artifacts': artifacts, 'trackedStatus': subprocess.check_output(['git', 'status', '--short', '--untracked-files=no'], cwd=REPO, text=True)}
if name.endswith('after'):
    before = json.loads((QA / (name[:-5] + 'before.json')).read_text())
    record['trackedDelta'] = [k for k in sorted(set(tracked) | set(before['tracked'])) if tracked.get(k) != before['tracked'].get(k)]
    record['artifactDelta'] = [k for k in sorted(set(artifacts) | set(before['artifacts'])) if artifacts.get(k) != before['artifacts'].get(k)]
    assert not record['trackedDelta'] and not record['artifactDelta'], 'QA inputs changed'
(QA / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k not in ['tracked']}, indent=2))
