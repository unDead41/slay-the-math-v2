#!/usr/bin/env python3
"""Package an explicit, privacy-approved immutable public allowlist; no folder walks."""
import argparse,datetime,gzip,hashlib,io,json,os,stat,tarfile
from pathlib import Path,PurePosixPath

def digest(b):return hashlib.sha256(b).hexdigest()
def safe(name):
 p=PurePosixPath(name)
 banned={'tmp','private','downloads','profiles','node_modules','payloads','recovered-blobs'}
 assert name and not p.is_absolute() and '..' not in p.parts and not (set(p.parts)&banned),name
 assert all(part not in {'.env','.git'} for part in p.parts),name
 return str(p)
def main():
 a=argparse.ArgumentParser();a.add_argument('--root',required=True);a.add_argument('--allowlist',required=True);a.add_argument('--out',required=True);x=a.parse_args()
 root=Path(x.root).resolve();allow=Path(x.allowlist);d=json.loads(allow.read_text());assert d['publicApproved'] is True and d['privacyStatus']=='PASS'
 originals=[];names=set()
 for row in d['files']:
  source=safe(row['source']);member=safe(row.get('member',source));assert member not in names,member;names.add(member)
  p=root/source;assert not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(root),source
  b=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
  assert len(b)==row['bytes'] and digest(b)==row['sha256'],source
  if 'mode' in row:assert mode==int(row['mode']),source
  originals.append({'source':source,'member':member,'bytes':len(b),'sha256':digest(b),'mode':mode})
 out=Path(x.out);out.mkdir(parents=True,exist_ok=True);archive=out/'public-evidence.tar.gz'
 with archive.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(mode='w|',fileobj=gz,format=tarfile.PAX_FORMAT) as tf:
    for row in sorted(originals,key=lambda y:y['member']):
     b=(root/row['source']).read_bytes();assert digest(b)==row['sha256']
     ti=tarfile.TarInfo(row['member']);ti.size=len(b);ti.mode=row['mode'];ti.mtime=ti.uid=ti.gid=0;ti.uname=ti.gname='';tf.addfile(ti,io.BytesIO(b))
 expected={row['member']:row for row in originals};seen=set()
 with tarfile.open(archive,'r:gz') as tf:
  for m in tf:
   safe(m.name);assert m.isfile() and m.name not in seen and m.name in expected,m.name;seen.add(m.name)
   b=tf.extractfile(m).read();row=expected[m.name];assert len(b)==row['bytes'] and digest(b)==row['sha256'] and m.mode==row['mode'],m.name
 assert seen==set(expected)
 for row in originals:assert digest((root/row['source']).read_bytes())==row['sha256'],row['source']
 b=archive.read_bytes();index={'schemaVersion':1,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publicApproved':True,'privacyStatus':'PASS','allowlistSha256':digest(allow.read_bytes()),'archive':{'file':archive.name,'bytes':len(b),'sha256':digest(b)},'memberCount':len(originals),'uncompressedBytes':sum(row['bytes'] for row in originals),'roundtrip':'PASS','sourceUnchanged':'PASS','limits':d.get('limits',[]),'files':originals}
 (out/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='files'}))
if __name__=='__main__':main()
