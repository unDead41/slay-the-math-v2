"""Independent exact-arithmetic probe. Usage: python math-oracle.py REPO OUTPUT."""
import datetime, hashlib, itertools, json, pathlib, subprocess, sys
from fractions import Fraction as F

repo, output = map(pathlib.Path, sys.argv[1:3])
cases = []

def fraction(x):
    return {'n': x.numerator, 'd': x.denominator}

def probability(operation, a, b=None, both=None, assumption=None, want=None, error=False):
    args = {'operation': operation, 'a': fraction(a)}
    if b is not None: args['b'] = fraction(b)
    if both is not None: args['both'] = fraction(both)
    if assumption is not None: args['assumption'] = assumption
    expected = None if error else {'fraction': str(want.numerator) + '/' + str(want.denominator)}
    cases.append({'tool': 'probability', 'args': args, 'expected': expected, 'error': error})

values = sorted({F(n, d) for d in range(1, 9) for n in range(d + 1)})
for a in values:
    probability('single', a, want=a)
    for b in values:
        probability('independent', a, b, assumption='independent', want=a*b)
        probability('sequential', a, b, assumption='conditional', want=a*b, error=a == 0)
        probability('conditional', a, b, want=a/b if b else None, error=not b or a > b)
        for both in {F(0), min(a, b), max(F(0), a+b-1)}:
            valid = 0 <= both <= min(a, b) and a+b-both <= 1
            probability('union', a, b, both, want=a+b-both, error=not valid)
        probability('independent', a, b, error=True)
        probability('sequential', a, b, error=True)
for operation in ['and', 'or', 'implies', 'not']:
    for a, b in itertools.product([False, True], repeat=2):
        want = {'and': a and b, 'or': a or b, 'implies': (not a) or b, 'not': not a}[operation]
        cases.append({'tool': 'logic', 'args': {'operation': operation, 'p': a, 'q': b},
                      'expected': {'value': want}, 'error': False})
universe = ['a', 'b', 'c']
subsets = [set(universe[i] for i in range(3) if mask >> i & 1) for mask in range(8)]
for a, b in itertools.product(subsets, repeat=2):
    for operation in ['union', 'intersection', 'difference', 'complement']:
        want = {'union': a|b, 'intersection': a&b, 'difference': a-b, 'complement': b-a}[operation]
        cases.append({'tool': 'sets', 'args': {'operation': operation, 'a': sorted(a), 'b': sorted(b)},
                      'expected': {'members': sorted(want), 'count': len(want)},
                      'error': operation == 'complement' and not a.issubset(b)})

script = """const fs=require('node:fs'),m=require(process.argv[1]);const c=JSON.parse(fs.readFileSync(0,'utf8'));const bad=[];for(let i=0;i<c.length;i++){const t=c[i];try{const v=m.calculate(t.tool,t.args);if(t.error){bad.push({i,reason:'expected refusal'});continue;}let actual=Object.fromEntries(Object.keys(t.expected).map(k=>[k,k==='members'?[...v[k]].sort():v[k]]));if(JSON.stringify(actual)!==JSON.stringify(t.expected))bad.push({i,actual,expected:t.expected});}catch(e){if(!t.error)bad.push({i,error:e.message});}}process.stdout.write(JSON.stringify({cases:c.length,pass:c.length-bad.length,fail:bad.length,failed:bad.slice(0,12)}));process.exitCode=bad.length?1:0;"""
source = repo / 'tools/pet/math.cjs'
inputs = json.dumps(cases)
result = subprocess.run(['node', '-e', script, str(source)], input=inputs, text=True, capture_output=True)
if result.returncode:
    raise SystemExit(result.stdout + result.stderr)
proof = json.loads(result.stdout)
proof.update({'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'method': 'Independent Python Fraction/set algebra/Boolean oracle; valid results and required refusals. Parameter checks only, no game simulation or pupil evidence.',
              'source': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              'file': 'tools/pet/math.cjs', 'sourceSHA256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'inputSHA256': hashlib.sha256(inputs.encode()).hexdigest(),
              'probeSHA256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'separateFromNodeTestCaseCount': True})
output.write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
