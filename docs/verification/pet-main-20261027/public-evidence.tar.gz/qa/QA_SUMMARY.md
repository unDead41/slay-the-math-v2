# QA — Mathematics Slayer 2.53.0 / Emberlyn

**CLOSED / VALID dalam skop yang diuji, dengan finding inherited dan had nyata.** Calon `728d25e7a9969b3570e7e8943664b9a6c43ce67c`, tree `2bb0b762478cc76243097cc9aba7300bebab6524`; ditutup `2026-10-27T13:53:17.315721+00:00`.

| Semakan baharu pada calon akhir | Hasil |
| --- | --- |
| Node tertumpu, 14 fail | **126/126 PASS**, 0 fail/skip/cancel, EOF lengkap. Termasuk 41 pet dan 4 branding; jangan kira dua kali. |
| Syntax | **PASS**, 7 fail pet/app/server. |
| Native pet | **54/54 PASS**, tambah binding actual versi/request2.53.0 dan nama semasa. |
| Cold offline produksi | **15/15 PASS**; proses browser baharu, server dihentikan, network disekat, HTTP cache dimatikan, SW/currentmanifest. 774 fail/237,492,918 bytes termasuk canonical manifest. |
| Portable | **2/2 PASS**, canonical EN/alias lama BM; versi2.53.0, exact PNG original, local maths, 0HTTP, old12-card save/RNG tepat. |
| Identiti | **3,750 tracked files tanpa delta**; kedua portable318,208,878B/SHA4811f778… sama. Source770entries/772offlinefiles dan production771/773 semuanya sepadan hash/saiz. |

Nama formal dan namespace save dikekalkan. Recovery401/409 menggunakan copy BM/EN yang dibenarkan, menyimpan fallback tempatan dan manual retry, serta menolak teks server arbitrari. Hint soalan aktif kekal melalui owner asal dengan accounting bantuan; tiada claim live model/anti-cheat umum. Dialog phone boleh scroll: bukti mengesahkan batas mendatar dan control boleh dicapai, bukan semua kandungan terlihat serentak.

Bukti owner1266 distinct PASS merentas command kekal sejarah; original fullFAIL2dependency/noEOF dan replay disjoint tidak dilabel satu suite hijau. Audit bebas memadankan274 source/222 test input pada076. Stable hanya8 fail version/generated berbeza; behavior/tests tidak berubah. 98 gambar dan batch/provenance lama dikekalkan:107/111input sepadan, empat perbezaan yang dinyatakan dalam evidence; app/engine/semua98gambar tepat. Tiada capture ulangan atau relabel.

**Privacy PASS:** tiada body save/session/RNG/backup, real player records, provider key sebenar atau classroom code sebenar diterbitkan. Expected auth configuration berada di server; code QA yang ditaip ialah tab-memory/Bearer, bukan provider key. P3 wording ini dimiliki final docs. Tiada runtime blocker tambahan ditemui.

CI-247-01, QA-248-PRELOAD-01 dan AM-U01 kekal dengan owner. Full suite, live provider/public backend, quality/latency/cost/retention, real classroom/physical/pupil/OS-reboot/browser-family/human-audio, MODEL.zip, simulation dan training **NOT_RUN**. QA tidak menulis main/ref.

[Bukti terperinci](evidence.json) · [Penutupan hash](after.json) · [Manifest sebenar](closing-verification.json) · [Privasi](privacy.json) · [Allowlist](artifact-index.json).
