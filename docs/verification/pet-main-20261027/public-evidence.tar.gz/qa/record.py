#!/usr/bin/env python3
"""Complete stdout through a parent pipe; one EOF log write and exact provenance."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

QA=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/e7745ff161c8/stm-pet-main-20261027')
BASE=ROOT.parent
name,*command=sys.argv[1:]
if not command: raise SystemExit('NAME COMMAND ...')
env=dict(os.environ)
env.update({
 'DOM_QA_MODULE':str(BASE/'pet-main-qa-deps/node_modules/jsdom'),
 'BROWSER_QA_MODULE':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright',
 'SHARP_QA_MODULE':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp',
 'IMAGE_QA_MODULE':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp',
 'NODE_PATH':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules:'+str(BASE/'pet-main-qa-deps/node_modules'),
 'QA_CHROMIUM_EXECUTABLE':'/tmp/chromium','FONTCONFIG_PATH':'/etc/fonts',
 'QA_PROFILE_ROOT':str(BASE/'pet-main-qa-tmp'),'TMPDIR':str(BASE/'pet-main-qa-tmp'),
 'NODE_OPTIONS':'--max-old-space-size=1792',
})
head=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=ROOT,text=True).splitlines()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
chunks=[]
for line in iter(process.stdout.readline,b''):
 chunks.append(line);sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
code=process.wait();raw=b''.join(chunks);(QA/(name+'.log')).write_bytes(raw)
record={'command':command,'cwd':str(ROOT),'startedUTC':start,'seconds':round(time.monotonic()-tick,3),'exitCode':code,'candidateSHA':head[0],'candidateTree':head[1],'environment':{k:env[k] for k in ['DOM_QA_MODULE','BROWSER_QA_MODULE','SHARP_QA_MODULE','IMAGE_QA_MODULE','NODE_PATH','QA_CHROMIUM_EXECUTABLE','FONTCONFIG_PATH','QA_PROFILE_ROOT','TMPDIR','NODE_OPTIONS','QA_OUTPUT'] if k in env},'log':name+'.log','logBytes':len(raw),'logSHA256':hashlib.sha256(raw).hexdigest(),'captureMethod':'Popen stdout pipe, direct terminal stream; complete raw log written once at EOF'}
(QA/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
raise SystemExit(code)
