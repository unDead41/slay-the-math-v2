from pathlib import Path
import subprocess,json,hashlib,re,tarfile,collections,filecmp
r=Path('.'); w=r/'.superpowers/sdd/2026-10-27-pet-recovery'; out=r/'docs/verification/pet-online-recovery'; out.mkdir(exist_ok=True)
base='7a49fff83388347f0157616fc6b051ddbda4c694'; source='5f5c547aaa606f9dd790ae5e3b99acd86516b0b7'; runtime='d980367'; current=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
h=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
 q=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):q.update(b)
 return q.hexdigest()
files=subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines()
protected=[p for p in files if (p.startswith('dist/') and not p.startswith('dist/assets/tutorial-shot-') and p not in ['dist/app.js','dist/index.html','dist/release.js','dist/asset-manifest.json','dist/education-practice.js']) or p.startswith(('tools/ai-playtester/','modules/map/','tools/balance/','tools/economy/'))]
for p in protected:assert (r/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
old=subprocess.check_output(['git','show',base+':dist/education-practice.js']);assert old.replace(b'2.52.0',b'2.53.0-pet.1')==(r/'dist/education-practice.js').read_bytes()
m=json.loads((r/'dist/asset-manifest.json').read_text()); cap=json.loads((r/'docs/tutorial/screenshots.json').read_text());assert len(cap['images'])==98 and cap['sourceCommit']==source and not cap['sourceWorkingTreeDirty']
for p,s in cap['runtimeInputs'].items():assert digest(r/'dist'/p)==s,p
for i in cap['images']:assert digest(r/'dist/assets'/i['file'])==i['sha256']
for e in m['offline']['files']:
 p=r/'dist'/e['url'];assert p.stat().st_size==e['bytes'] and digest(p)==e['sha256'],str(p)

prod=json.loads((r/'release-prod/asset-manifest.json').read_text())
for e in prod['offline']['files']:
 p=r/'release-prod'/e['url'];assert p.stat().st_size==e['bytes'] and digest(p)==e['sha256'],str(p)
owner=json.loads((w/'production-owner.json').read_text());assert owner['appMatchesCurrentInstrumentApp'] and owner['indexMatchesCurrentInjection']
for p in ['tools/build-production.cjs','tools/dev/build-production.cjs','tools/dev/server.cjs','tools/build-asset-manifest.cjs','build-portable.cjs']:assert (r/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
new=['pet-config.js','pet-knowledge.js','pet-assistant.js','pet-assistant.css','assets/pet-emberlyn-original.png'];entries={e['url']:e for e in m['entries']};offline={e['url']:e for e in m['offline']['files']}
for p in new:
 assert entries[p]['sha256']==offline[p]['sha256']==digest(r/'dist'/p)
 assert (r/'dist'/p).read_bytes()==(r/'release-prod'/p).read_bytes()
assert digest(r/'dist/assets/pet-emberlyn-original.png')=='51ac96816818d22a27d469286926863f32b362e90c33dca5d62a1bbaa075a2fc'
public=[p.as_posix() for p in (r/'release-prod').rglob('*') if p.is_file()];assert not any('/tools/' in p or Path(p).name.startswith('.env') or '/backend/' in p for p in public)
canonical=r/'MATHEMATICS-SLAYER-OFFLINE.html'; alias=r/'SLAY-THE-MATH-OFFLINE.html';assert filecmp.cmp(canonical,alias,shallow=False)
actual={p:digest(r/'dist'/p) for p in cap['runtimeInputs']};actual.update({p:digest(r/p) for p in ['server.cjs','tools/pet/server.cjs','tools/pet/math.cjs','package.json','.env.example']})
nodeinputs={p.as_posix():digest(p) for p in sorted((r/'tests').glob('*.test.cjs'))}
for p,s in nodeinputs.items():assert s==h(subprocess.check_output(['git','show',runtime+':'+p])),p
(out/'source-hashes.json').write_text(json.dumps({'baseMain':base,'fullNodeStartCommit':subprocess.check_output(['git','rev-parse',runtime],text=True).strip(),'nativeHarnessCommit':current,'runtime':actual,'nodeTestInputs':nodeinputs,'allNodeInputsUnchangedSinceFullStart':True},indent=2)+'\n')
def names(name):return [re.sub(r' \([^\n]*\)$','',v.strip()[2:]) for v in (w/name).read_text().splitlines() if v.lstrip().startswith('✔ ')]
a=names('full-suite-final.log');b=names('full-suite-tail.log');assert len(a)==1162 and len(set(a))==1162 and len(b)==95 and len(set(b))==95 and not set(a)&set(b)
full=(w/'full-suite-final.log').read_text();tail=(w/'full-suite-tail.log').read_text();assert 'ℹ tests ' not in full and 'ℹ tests 95' in tail and 'ℹ pass 95' in tail and 'ℹ fail 0' in tail and 'ℹ skipped 0' in tail and not re.search(r'^\s*✖',full,re.M)
(out/'node-coverage.json').write_text(json.dumps({'fullCommand':'node --test --test-concurrency=1 tests/*.test.cjs','fullExitCode':0,'fullStdout':'INCOMPLETE_CAPTURE','retainedFullPassCases':a,'freshDisjointTailCases':b,'intersectionCount':0,'distinctRecordedCases':len(set(a)|set(b)),'tailExitCode':0,'tailSummary':{'tests':95,'pass':95,'fail':0,'skip':0,'cancel':0},'overlappingProbeExcluded':18,'notClaimed':'No fabricated 1257/1257 single-run EOF summary or unknown full-run skip/duration counts.'},indent=2)+'\n')
records={}
for folder,expected in [('browser',36),('offline',15)]:
 p=out/folder/'report.json';v=json.loads(p.read_text());assert v['version']=='2.53.0-pet.1' and len(v['checks'])==expected and not v['errors'];records[folder]={'checks':expected,'errors':0,'reportSHA256':digest(p),'exitCode':0}
 if folder=='browser':assert all(c['passed'] for c in v['checks'])
 else:
  assert v['cold']['serverStopped'] and v['cold']['newBrowserProcess'] and v['cold']['serviceWorkerNavigation']
  assert v['installation']['releaseId']==prod['offline']['releaseId']
summary={'sessionDate':'2026-10-27','baseMain':base,'masterSOR':'1.3.0','branch':'ai/pet-online-20261025','version':'2.53.0-pet.1','captureSource':{'localCommit':source,'tree':'6e9f20861b5c19fe272161daf4258d4113b77133','githubEquivalentCommit':'1c4d86f4f876ccec4821c70acd12846e08ba09e0','exactTreeEquality':True,'cleanTrackedStart':True},'runtimeCandidate':subprocess.check_output(['git','rev-parse',runtime],text=True).strip(),'nativeHarnessCandidate':current,'focused':{'tests':36,'pass':36,'components':{'api':19,'widget':10,'realAppConsumers':3,'branding':4}},'reviewRegressions':{'red':{'pass':27,'fail':5},'green':{'pass':32,'fail':0}},'fullNode':{'exitCode':0,'stdout':'INCOMPLETE_CAPTURE','recordedPassCases':1162,'freshDisjointTail':95,'distinctRecordedCases':1257,'singleRunTotalNotClaimed':True},'native':records,'tutorial':{'images':98,'languages':{'en':49,'ms':49},'runtimeInputs':len(cap['runtimeInputs']),'allInputAndImageHashesMatch':True,'strictMediaTests':3},'build':{'syntaxExitCode':0,'portableBuildExitCode':0,'productionBuildExitCode':0,'offlineFilesVerified':len(m['offline']['files']),'manifestId':m['manifestId'],'offlineReleaseId':m['offline']['releaseId'],'production':{'offlineFilesVerified':len(prod['offline']['files']),'manifestPlusRetainedFiles':len(prod['offline']['files'])+1,'releaseId':prod['offline']['releaseId'],'appIndexExactlyMatchUnchangedBuildOwner':True,'newPetFilesByteEqualToSource':True},'portable':{'canonical':canonical.name,'alias':alias.name,'byteIdentical':True,'bytes':canonical.stat().st_size,'sha256':digest(canonical)}},'boundaries':{'protectedTrackedFilesEqual':len(protected),'practiceBundle':'only package version string differs','newPublicAssets':[entries[p] for p in new],'productionContainsNoBackendToolsOrEnvFiles':True},'provider':{'realPaidCall':'NOT_RUN','fakeUpstreamOnly':True,'externalDeployment':'NOT_RUN'},'review':{'status':'TECHNICAL_PASS_COMPLETE_AWAITING_FINAL_RECEIPT_VERDICT','fixedImportant':['pending question guarded on Main Menu; original Continue/Hint accounting','restored original-card hand IDs and read-only engine.definition facts','unusable Unicode/whitespace classroom-code configuration rejected'],'deferredMinor':['file-origin remote-Online guide suggestion is unsupported; audit erratum requires hosted Online','safe server error codes are replaced by generic client/local fallback']},'limits':['Shared code/in-memory per-process caps; no distributed/per-student quota claim','Normal-flow support accounting only; no adversarial anti-cheat claim','No real provider, whole-book/all120 audit, pupil/device/browser/audio acceptance, new ML/campaign or long-term persistence claim','Inherited CI-247-01, QA-248-PRELOAD-01 and AM-U01 remain open']}
(out/'evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
ledger=(w/'progress.md').read_text();rulings=[x for x in ledger.splitlines() if 'Ruling:' in x or 'minor (deferred)' in x];(out/'review-rulings.md').write_text('# Decisions, costs and deferred minors\n\n'+'\n\n'.join('- '+x for x in rulings)+'\n')
with tarfile.open(out/'qa-logs.tar.gz','w:gz') as archive:
 for p in sorted(w.rglob('*')):
  if p.is_file() and (p.suffix=='.log' or p.name in ['progress.md','collect-evidence.py']):archive.add(p,arcname=p.relative_to(w).as_posix())
print(json.dumps({'protectedFilesEqual':len(protected),'offlineFilesVerified':len(m['offline']['files']),'nodeRecordedCases':1257,'native':records,'runtimeInputs':len(actual),'archiveBytes':(out/'qa-logs.tar.gz').stat().st_size}))
