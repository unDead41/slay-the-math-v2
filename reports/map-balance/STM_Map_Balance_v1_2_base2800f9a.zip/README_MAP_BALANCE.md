# SLAY THE MATH — MAP BALANCE v1.2

Read docs/MAP_BALANCE_HANDOFF.md and modules/map/SOR/04_MAP_COMBAT_POWER.md.

100 seeds / 200 maps / 5,500 stage routes / 77,384 legal two-stage route pairs.
800 sampled + 300 diagnostic canonical-engine campaigns; pilot 320/800 full-run victories.
Synthetic Challenge policy; not calibrated pupil difficulty. CP is developer-only.

Base: 2800f9aeba5ed594e6ef3f991bcf4dfa498a5de7. This is an audit/code/report overlay, not a standalone game. Review on an isolated checkout. Master integrates domain changes; preserve other chats and do not publish main.

All files have SHA-256 entries in PACKAGE_MANIFEST.json. Pair JSON is in four indexed chunks. Original local Git history is provided separately beside this ZIP at reports/map-balance/ORIGINAL_AUDIT_HISTORY.bundle on branch balance/map; its URL/hash are in the manifest. The base repo is its prerequisite. Remote delivery may use different commit metadata while preserving the reviewed file contents.
